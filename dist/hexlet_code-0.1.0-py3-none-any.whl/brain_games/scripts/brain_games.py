#!/usr/bin/env python3

from brain_games.cli import welcome_user

def main():
    welcome_user()


if __name__ == '__main__':
    main()

# poetry run python -m brain_games.scripts.brain_games
# Welcome to the Brain Games!